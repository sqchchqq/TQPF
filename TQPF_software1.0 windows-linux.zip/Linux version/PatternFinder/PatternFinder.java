import java.io.File; 
public class PatternFinder {
       
      public static void main(String[] args) {
	
		File DNA_Seq=new File("/home/chenqi/tq/AA/21anti.fasta");
	 	String pattern="TTTVNNNNNNNNNNNNNNNNNNNNNGG";
                int gcMin=9; int gcMax=19; int Nn_exclude=5;				
		File Rdir=new File("/home/chenqi/tq/AA/OUT");  
		
	        new FindTargets(DNA_Seq, pattern,gcMin,gcMax,Nn_exclude,Rdir);  		   	     
		 		
		System.out.println(" good work finished ! ");		
         }
 }
