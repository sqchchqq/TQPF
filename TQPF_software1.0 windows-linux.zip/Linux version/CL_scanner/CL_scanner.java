import java.io.File;   
import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  
public class CL_scanner {  
	 public static void main(String[] arg){ 
            ExecutorService es=Executors.newFixedThreadPool(3);  

             String species="Human";
	     String Off_GenomeGeneDir="/home/chenqi/tq/cripsr/GenomeGene_location";
             File[] Off_TsF=(new File("/home/chenqi/tq/AA/IN2")).listFiles();
	     File OUTdir=new File("/home/chenqi/tq/AA/OUT2");
             int allowedMissNum=7; int NumAtSameTimeRun=3;
            
            String Off_genomeDir=Off_GenomeGeneDir+"/"+species+"GenomeFasta";
	    File   geneLocationInfDir=new File(Off_GenomeGeneDir+"/"+species+"GeneLocationInf");
            File   chroLength=new File(Off_GenomeGeneDir+"/"+species+"_Chromosome_length.txt");       
	    GenomeFasta2 GS=new GenomeFasta2(Off_genomeDir);          
	    for(File Ts: Off_TsF){ 
	        es.submit(new FindOffTarget2(GS,chroLength,geneLocationInfDir, Ts,OUTdir,allowedMissNum,NumAtSameTimeRun )); 
	    }
	    es.shutdown();	
	}
     
     
 } 
