import java.io.File;

public class CLstatistics {
        	
	 public static void main(String[] arg){
									      				
		File rawData=new File("/home/chenqi/tq/AA/OUT2"); String outDir ="/home/chenqi/tq/AA/O"; int missMatchNum=7;
		
                File[] inS=rawData.listFiles();   
		ExactInform EI=new ExactInform();
	        for(File s: inS){			
			File ous= new File(outDir+"/"+s.getName());
			EI.getOffTargets(s, ous, missMatchNum); 
			System.out.println(" N(mmN,0)  finished ! "+s.getName());
		}	
					 
	}

}
